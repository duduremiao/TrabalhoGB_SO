package com.trabalho_gb;

public class Pagina{

    String paginaConteudo;

    public String getConteudoPagina() {
        return paginaConteudo;
    }

    public void setConteudoPagina(String paginaConteudo) {
        this.paginaConteudo = paginaConteudo;
    }

}