package com.trabalho_gb;

public class Frame {


    private String conteudo;

    public String getConteudoFrame() {
        return conteudo;
    }

    public void setConteudoFrame(String conteudo) {
        this.conteudo = conteudo;
    }
}